<html>
<head>
<title>
Template for the student admin application 
</title>

<link rel="stylesheet" href="mainstyle.css" type="text/css" />

</head>
<body>
<div class="container">
<div class='top'>
   <div class='title'><h1>Uni-Marks Student Home Page</h1></div>
   <div class='login'>You are logged in as Hans Muster</div>
   </div>
   

   <div class="menu">
   <div class="menu-item"><a href="index.php">Menu item 1</a></div>
   <div class="menu-item"><a href="index.php">Menu item 2</a></div>
   <div class="menu-item"><a href="index.php">Menu item 3</a></div>
   <div class="menu-item"><a href="index.php">Menu item 4</a></div>
   </div>

   <div class="content">
   <h2>List of your marks</h2>

   <div class="line">Math 1.7 </div>
   <div class="line">English 2.7 </div>
   <div class="line">French 1.0 </div>

   
   </div>
  <div class="footer">Copyright E.Benoist 2011, all rights reserved (even the one that it does not work)</div>
</div>


</body>
</html>