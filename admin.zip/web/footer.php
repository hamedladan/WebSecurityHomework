<div class="footer">Copyright E.Benoist 2011, all rights reserved<br />
   (This server is striclty educational and should in no case be used for any real purpose!)</div>